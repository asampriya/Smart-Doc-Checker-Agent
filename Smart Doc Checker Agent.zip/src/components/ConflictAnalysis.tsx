import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { AlertTriangle, CheckCircle, XCircle, Lightbulb, FileText, ArrowRight } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: string;
  uploadDate: string;
  status: string;
  conflicts?: number;
}

interface Conflict {
  id: string;
  type: 'policy' | 'compliance' | 'ambiguity';
  severity: 'low' | 'medium' | 'high';
  description: string;
  documents: string[];
  recommendation: string;
  status: 'unresolved' | 'resolved';
}

interface ConflictAnalysisProps {
  conflicts: Conflict[];
  documents: Document[];
  onRefresh: () => void;
}

export function ConflictAnalysis({ conflicts, documents, onRefresh }: ConflictAnalysisProps) {
  const [selectedConflict, setSelectedConflict] = useState<Conflict | null>(null);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'low':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'policy':
        return 'bg-blue-100 text-blue-800';
      case 'compliance':
        return 'bg-purple-100 text-purple-800';
      case 'ambiguity':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'medium':
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      case 'low':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return <AlertTriangle className="h-4 w-4 text-gray-600" />;
    }
  };

  const getDocumentName = (docId: string) => {
    const doc = documents.find(d => d.id === docId);
    return doc ? doc.name : 'Unknown Document';
  };

  const handleResolveConflict = async (conflictId: string) => {
    try {
      // TODO: Implement resolve conflict API call
      console.log('Resolving conflict:', conflictId);
      onRefresh();
    } catch (error) {
      console.error('Error resolving conflict:', error);
    }
  };

  const unresolvedConflicts = conflicts.filter(c => c.status === 'unresolved');
  const resolvedConflicts = conflicts.filter(c => c.status === 'resolved');
  const highPriorityConflicts = unresolvedConflicts.filter(c => c.severity === 'high');

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-2xl">{unresolvedConflicts.length}</p>
                <p className="text-sm text-gray-600">Unresolved</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <XCircle className="h-5 w-5 text-red-600" />
              <div>
                <p className="text-2xl">{highPriorityConflicts.length}</p>
                <p className="text-sm text-gray-600">High Priority</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl">{resolvedConflicts.length}</p>
                <p className="text-sm text-gray-600">Resolved</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Lightbulb className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl">{conflicts.length}</p>
                <p className="text-sm text-gray-600">Total Issues</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="unresolved" className="space-y-4">
        <TabsList>
          <TabsTrigger value="unresolved">
            Unresolved ({unresolvedConflicts.length})
          </TabsTrigger>
          <TabsTrigger value="resolved">
            Resolved ({resolvedConflicts.length})
          </TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="unresolved" className="space-y-4">
          {unresolvedConflicts.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle className="mx-auto h-12 w-12 text-green-600 mb-4" />
                <h3 className="text-lg mb-2">No Unresolved Conflicts</h3>
                <p className="text-gray-500">
                  Great! All conflicts have been resolved or no conflicts were detected.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {unresolvedConflicts.map((conflict) => (
                <Card key={conflict.id} className="border-l-4 border-l-red-500">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {getSeverityIcon(conflict.severity)}
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge className={getSeverityColor(conflict.severity)}>
                              {conflict.severity} priority
                            </Badge>
                            <Badge className={getTypeColor(conflict.type)}>
                              {conflict.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            Affects {conflict.documents.length} document{conflict.documents.length > 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleResolveConflict(conflict.id)}
                      >
                        Mark Resolved
                      </Button>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <h4 className="mb-2">Issue Description</h4>
                        <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">
                          {conflict.description}
                        </p>
                      </div>

                      <div>
                        <h4 className="mb-2">Affected Documents</h4>
                        <div className="flex flex-wrap gap-2">
                          {conflict.documents.map((docId) => (
                            <div key={docId} className="flex items-center space-x-1 bg-blue-50 px-2 py-1 rounded text-sm">
                              <FileText className="h-3 w-3 text-blue-600" />
                              <span>{getDocumentName(docId)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h4 className="flex items-center space-x-2 mb-2">
                          <Lightbulb className="h-4 w-4 text-blue-600" />
                          <span>AI Recommendation</span>
                        </h4>
                        <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded">
                          {conflict.recommendation}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="resolved" className="space-y-4">
          {resolvedConflicts.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <AlertTriangle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg mb-2">No Resolved Conflicts</h3>
                <p className="text-gray-500">
                  Resolved conflicts will appear here once you mark them as resolved.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {resolvedConflicts.map((conflict) => (
                <Card key={conflict.id} className="border-l-4 border-l-green-500 opacity-75">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <CheckCircle className="h-5 w-5 text-green-600" />
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <Badge className="bg-green-100 text-green-800">
                              Resolved
                            </Badge>
                            <Badge className={getTypeColor(conflict.type)}>
                              {conflict.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            Previously: {conflict.severity} priority
                          </p>
                        </div>
                      </div>
                    </div>

                    <p className="text-sm text-gray-700">
                      {conflict.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Insights</CardTitle>
              <CardDescription>
                Smart analysis and recommendations based on your document library
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <h4 className="flex items-center space-x-2 mb-2">
                    <Lightbulb className="h-4 w-4 text-blue-600" />
                    <span>Pattern Detection</span>
                  </h4>
                  <p className="text-sm text-gray-700">
                    Common conflict patterns identified across similar document types.
                  </p>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <h4 className="flex items-center space-x-2 mb-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span>Compliance Score</span>
                  </h4>
                  <p className="text-sm text-gray-700">
                    Overall compliance rating based on current document analysis.
                  </p>
                </div>

                <div className="bg-orange-50 p-4 rounded-lg">
                  <h4 className="flex items-center space-x-2 mb-2">
                    <AlertTriangle className="h-4 w-4 text-orange-600" />
                    <span>Risk Assessment</span>
                  </h4>
                  <p className="text-sm text-gray-700">
                    Potential risks identified through cross-document analysis.
                  </p>
                </div>

                <div className="bg-purple-50 p-4 rounded-lg">
                  <h4 className="flex items-center space-x-2 mb-2">
                    <ArrowRight className="h-4 w-4 text-purple-600" />
                    <span>Next Steps</span>
                  </h4>
                  <p className="text-sm text-gray-700">
                    Recommended actions to improve document consistency.
                  </p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="mb-3">Recent Analysis Trends</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Policy Conflicts</span>
                    <span className="text-orange-600">
                      {conflicts.filter(c => c.type === 'policy').length} detected
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Compliance Issues</span>
                    <span className="text-red-600">
                      {conflicts.filter(c => c.type === 'compliance').length} detected
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Ambiguities</span>
                    <span className="text-yellow-600">
                      {conflicts.filter(c => c.type === 'ambiguity').length} detected
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}