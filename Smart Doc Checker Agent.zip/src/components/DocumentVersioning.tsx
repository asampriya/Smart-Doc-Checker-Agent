import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { GitBranch, History, Download, Eye, ArrowRightLeft, Clock, User, FileText, ArrowRight, RotateCcw } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  type: string;
  uploadDate: string;
  status: string;
  version?: number;
  lastModified?: string;
  modifiedBy?: string;
}

interface DocumentVersion {
  id: string;
  documentId: string;
  version: number;
  createdAt: string;
  createdBy: string;
  changes: string;
  size: number;
  status: 'current' | 'archived';
  conflictCount?: number;
}

interface DocumentVersioningProps {
  documents: Document[];
  onRefresh: () => void;
}

export function DocumentVersioning({ documents, onRefresh }: DocumentVersioningProps) {
  const [selectedDocument, setSelectedDocument] = useState<string | null>(null);
  const [isCompareDialogOpen, setIsCompareDialogOpen] = useState(false);
  const [compareVersions, setCompareVersions] = useState<[string, string] | null>(null);

  // Mock version data for demo
  const mockVersions: DocumentVersion[] = [
    {
      id: 'v1',
      documentId: 'demo_doc_1',
      version: 3,
      createdAt: '2024-01-20T15:30:00Z',
      createdBy: 'Sarah Johnson',
      changes: 'Updated remote work policy section, added new security requirements',
      size: 245760,
      status: 'current',
      conflictCount: 0
    },
    {
      id: 'v2',
      documentId: 'demo_doc_1',
      version: 2,
      createdAt: '2024-01-18T10:15:00Z',
      createdBy: 'Mike Chen',
      changes: 'Fixed formatting issues, corrected legal references',
      size: 243520,
      status: 'archived',
      conflictCount: 1
    },
    {
      id: 'v3',
      documentId: 'demo_doc_1',
      version: 1,
      createdAt: '2024-01-15T14:20:00Z',
      createdBy: 'Emily Davis',
      changes: 'Initial version uploaded',
      size: 241280,
      status: 'archived',
      conflictCount: 2
    },
    {
      id: 'v4',
      documentId: 'demo_doc_2',
      version: 2,
      createdAt: '2024-01-19T11:45:00Z',
      createdBy: 'Sarah Johnson',
      changes: 'Updated HIPAA compliance requirements',
      size: 156720,
      status: 'current',
      conflictCount: 0
    },
    {
      id: 'v5',
      documentId: 'demo_doc_2',
      version: 1,
      createdAt: '2024-01-12T16:30:00Z',
      createdBy: 'Dr. Williams',
      changes: 'Initial patient consent form',
      size: 154880,
      status: 'archived',
      conflictCount: 1
    }
  ];

  const getVersionsForDocument = (documentId: string) => {
    return mockVersions.filter(v => v.documentId === documentId).sort((a, b) => b.version - a.version);
  };

  const handleRevertToVersion = async (versionId: string) => {
    if (confirm('Are you sure you want to revert to this version? This will create a new version.')) {
      try {
        // TODO: Implement version revert
        console.log('Reverting to version:', versionId);
        onRefresh();
      } catch (error) {
        console.error('Error reverting version:', error);
      }
    }
  };

  const handleDownloadVersion = async (versionId: string) => {
    try {
      // TODO: Implement version download
      console.log('Downloading version:', versionId);
    } catch (error) {
      console.error('Error downloading version:', error);
    }
  };

  const formatFileSize = (bytes: number) => {
    const sizes = ['B', 'KB', 'MB', 'GB'];
    if (bytes === 0) return '0 B';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return Math.round(bytes / Math.pow(1024, i) * 100) / 100 + ' ' + sizes[i];
  };

  const documentsWithVersions = documents.filter(doc => 
    mockVersions.some(v => v.documentId === doc.id)
  );

  // Add demo documents if none exist
  const demoDocuments = [
    {
      id: 'demo_doc_1',
      name: 'Employee_Handbook_2024.pdf',
      type: 'policy',
      uploadDate: '2024-01-15T14:20:00Z',
      status: 'analyzed',
      version: 3,
      lastModified: '2024-01-20T15:30:00Z',
      modifiedBy: 'Sarah Johnson'
    },
    {
      id: 'demo_doc_2',
      name: 'Patient_Consent_Form.pdf',
      type: 'medical',
      uploadDate: '2024-01-12T16:30:00Z',
      status: 'analyzed',
      version: 2,
      lastModified: '2024-01-19T11:45:00Z',
      modifiedBy: 'Sarah Johnson'
    }
  ];

  const displayDocuments = documentsWithVersions.length > 0 ? documentsWithVersions : demoDocuments;

  const totalVersions = mockVersions.length;
  const averageVersionsPerDoc = Math.round(totalVersions / displayDocuments.length * 10) / 10;
  const recentChanges = mockVersions.filter(v => 
    new Date(v.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
  ).length;

  return (
    <div className="space-y-6">
      {/* Version Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <GitBranch className="h-5 w-5 text-primary" />
              <div>
                <p className="text-2xl">{totalVersions}</p>
                <p className="text-sm text-muted-foreground">Total Versions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl">{displayDocuments.length}</p>
                <p className="text-sm text-muted-foreground">Versioned Docs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <History className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl">{averageVersionsPerDoc}</p>
                <p className="text-sm text-muted-foreground">Avg Versions</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-2xl">{recentChanges}</p>
                <p className="text-sm text-muted-foreground">Recent Changes</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Document Selection */}
      <Card>
        <CardHeader>
          <CardTitle>Document Version History</CardTitle>
          <CardDescription>
            Track changes and manage versions of your documents over time
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            {displayDocuments.map((document) => {
              const versions = getVersionsForDocument(document.id);
              const isSelected = selectedDocument === document.id;
              
              return (
                <Card 
                  key={document.id} 
                  className={`cursor-pointer transition-colors ${
                    isSelected ? 'border-primary bg-primary/5' : 'hover:border-border'
                  }`}
                  onClick={() => setSelectedDocument(isSelected ? null : document.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <FileText className="h-4 w-4 text-primary" />
                        <h4 className="font-medium text-sm truncate">{document.name}</h4>
                      </div>
                      <Badge variant="outline">v{document.version || versions[0]?.version || 1}</Badge>
                    </div>
                    
                    <div className="space-y-2 text-xs text-muted-foreground">
                      <div className="flex items-center space-x-1">
                        <GitBranch className="h-3 w-3" />
                        <span>{versions.length} versions</span>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <User className="h-3 w-3" />
                        <span>Modified by {document.modifiedBy || versions[0]?.createdBy || 'Unknown'}</span>
                      </div>
                      
                      <div className="flex items-center space-x-1">
                        <Clock className="h-3 w-3" />
                        <span>{new Date(document.lastModified || versions[0]?.createdAt || document.uploadDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Version History for Selected Document */}
          {selectedDocument && (
            <div className="border-t pt-6">
              <h3 className="text-lg font-medium mb-4">
                Version History - {displayDocuments.find(d => d.id === selectedDocument)?.name}
              </h3>
              
              <div className="space-y-3">
                {getVersionsForDocument(selectedDocument).map((version, index) => (
                  <div key={version.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="flex flex-col items-center">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          version.status === 'current' 
                            ? 'bg-green-100 text-green-800' 
                            : 'bg-gray-100 text-gray-600'
                        }`}>
                          <span className="text-xs font-medium">v{version.version}</span>
                        </div>
                        {index < getVersionsForDocument(selectedDocument).length - 1 && (
                          <div className="w-0.5 h-6 bg-border mt-2"></div>
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge variant={version.status === 'current' ? 'default' : 'secondary'}>
                            {version.status === 'current' ? 'Current' : 'Archived'}
                          </Badge>
                          {version.conflictCount !== undefined && version.conflictCount > 0 && (
                            <Badge variant="destructive">
                              {version.conflictCount} conflicts
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm font-medium mb-1">{version.changes}</p>
                        
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                          <div className="flex items-center space-x-1">
                            <User className="h-3 w-3" />
                            <span>{version.createdBy}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>{new Date(version.createdAt).toLocaleString()}</span>
                          </div>
                          <span>{formatFileSize(version.size)}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDownloadVersion(version.id)}
                      >
                        <Download className="h-4 w-4" />
                      </Button>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          // TODO: Implement version preview
                          console.log('Preview version:', version.id);
                        }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      
                      {version.status !== 'current' && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRevertToVersion(version.id)}
                        >
                          <RotateCcw className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Version Comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Version Comparison</CardTitle>
          <CardDescription>
            Compare changes between different versions of your documents
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Select a document above to see its version history and compare changes between versions.
            </p>
            
            {selectedDocument && getVersionsForDocument(selectedDocument).length > 1 && (
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">Compare:</span>
                    <select className="text-sm border rounded px-2 py-1">
                      {getVersionsForDocument(selectedDocument).map(v => (
                        <option key={v.id} value={v.id}>v{v.version}</option>
                      ))}
                    </select>
                  </div>
                  
                  <ArrowRightLeft className="h-4 w-4 text-muted-foreground" />
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-sm font-medium">With:</span>
                    <select className="text-sm border rounded px-2 py-1">
                      {getVersionsForDocument(selectedDocument).map(v => (
                        <option key={v.id} value={v.id}>v{v.version}</option>
                      ))}
                    </select>
                  </div>
                  
                  <Button size="sm">
                    <ArrowRightLeft className="h-4 w-4 mr-2" />
                    Compare
                  </Button>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Version Control Best Practices */}
      <Card>
        <CardHeader>
          <CardTitle>Version Control Best Practices</CardTitle>
          <CardDescription>
            Tips for effective document version management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-medium">Documentation Tips</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Always include meaningful change descriptions</li>
                <li>• Use version numbers that reflect change significance</li>
                <li>• Tag important milestones and releases</li>
                <li>• Keep detailed change logs for compliance</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-medium">Collaboration Guidelines</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Coordinate with team before major changes</li>
                <li>• Review versions before marking as current</li>
                <li>• Use branches for experimental changes</li>
                <li>• Archive old versions to maintain history</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}