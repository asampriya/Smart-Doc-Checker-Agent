import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Shield, AlertTriangle, CheckCircle, Clock, RefreshCw, Bell, Settings } from 'lucide-react';

interface ComplianceUpdate {
  id: string;
  source: string;
  title: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  date: string;
  category: string;
  affectedDocuments: number;
  status: 'new' | 'reviewed' | 'implemented';
}

interface ComplianceMonitorProps {
  onRefresh: () => void;
}

export function ComplianceMonitor({ onRefresh }: ComplianceMonitorProps) {
  const [updates, setUpdates] = useState<ComplianceUpdate[]>([
    {
      id: '1',
      source: 'Federal Register',
      title: 'Updated GDPR Data Processing Guidelines',
      description: 'New requirements for data processing consent documentation and retention policies.',
      severity: 'high',
      date: '2024-01-15',
      category: 'Data Privacy',
      affectedDocuments: 3,
      status: 'new'
    },
    {
      id: '2',
      source: 'Healthcare.gov',
      title: 'HIPAA Security Rule Updates',
      description: 'Enhanced requirements for electronic health information safeguards.',
      severity: 'medium',
      date: '2024-01-12',
      category: 'Healthcare',
      affectedDocuments: 2,
      status: 'reviewed'
    },
    {
      id: '3',
      source: 'Department of Labor',
      title: 'Employment Contract Disclosure Requirements',
      description: 'New mandatory disclosures for remote work arrangements and benefits.',
      severity: 'medium',
      date: '2024-01-10',
      category: 'Employment',
      affectedDocuments: 5,
      status: 'implemented'
    }
  ]);

  const [monitoredSources, setMonitoredSources] = useState([
    { name: 'Federal Register', active: true, category: 'Government' },
    { name: 'Healthcare.gov', active: true, category: 'Healthcare' },
    { name: 'Department of Labor', active: true, category: 'Employment' },
    { name: 'SEC.gov', active: false, category: 'Financial' },
    { name: 'FDA.gov', active: false, category: 'Medical Devices' }
  ]);

  const [isChecking, setIsChecking] = useState(false);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'medium':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'low':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'new':
        return 'bg-blue-100 text-blue-800';
      case 'reviewed':
        return 'bg-orange-100 text-orange-800';
      case 'implemented':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'medium':
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      case 'low':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return <Shield className="h-4 w-4 text-gray-600" />;
    }
  };

  const handleCheckForUpdates = async () => {
    setIsChecking(true);
    // Simulate API call to check for compliance updates
    setTimeout(() => {
      setIsChecking(false);
      // Would normally fetch real updates here
    }, 2000);
  };

  const handleMarkAsReviewed = (updateId: string) => {
    setUpdates(prev => prev.map(update => 
      update.id === updateId ? { ...update, status: 'reviewed' } : update
    ));
  };

  const handleMarkAsImplemented = (updateId: string) => {
    setUpdates(prev => prev.map(update => 
      update.id === updateId ? { ...update, status: 'implemented' } : update
    ));
  };

  const newUpdates = updates.filter(u => u.status === 'new');
  const reviewedUpdates = updates.filter(u => u.status === 'reviewed');
  const implementedUpdates = updates.filter(u => u.status === 'implemented');
  const highPriorityUpdates = updates.filter(u => u.severity === 'high' && u.status !== 'implemented');

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5 text-blue-600" />
              <div>
                <p className="text-2xl">{newUpdates.length}</p>
                <p className="text-sm text-gray-600">New Updates</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5 text-red-600" />
              <div>
                <p className="text-2xl">{highPriorityUpdates.length}</p>
                <p className="text-sm text-gray-600">High Priority</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-orange-600" />
              <div>
                <p className="text-2xl">{reviewedUpdates.length}</p>
                <p className="text-sm text-gray-600">Under Review</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl">{implementedUpdates.length}</p>
                <p className="text-sm text-gray-600">Implemented</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Check for Updates */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Compliance Monitoring</CardTitle>
              <CardDescription>
                Stay up-to-date with the latest regulatory changes and requirements
              </CardDescription>
            </div>
            <Button onClick={handleCheckForUpdates} disabled={isChecking}>
              {isChecking ? (
                <div className="flex items-center space-x-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current"></div>
                  <span>Checking...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <RefreshCw className="h-4 w-4" />
                  <span>Check for Updates</span>
                </div>
              )}
            </Button>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="new" className="space-y-4">
        <TabsList>
          <TabsTrigger value="new">
            New Updates ({newUpdates.length})
          </TabsTrigger>
          <TabsTrigger value="reviewed">
            Under Review ({reviewedUpdates.length})
          </TabsTrigger>
          <TabsTrigger value="implemented">
            Implemented ({implementedUpdates.length})
          </TabsTrigger>
          <TabsTrigger value="sources">
            Monitored Sources
          </TabsTrigger>
        </TabsList>

        <TabsContent value="new" className="space-y-4">
          {newUpdates.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle className="mx-auto h-12 w-12 text-green-600 mb-4" />
                <h3 className="text-lg mb-2">All Caught Up!</h3>
                <p className="text-gray-500">
                  No new compliance updates at this time. We'll notify you when new requirements are published.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {newUpdates.map((update) => (
                <Card key={update.id} className="border-l-4 border-l-blue-500">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {getSeverityIcon(update.severity)}
                        <div>
                          <h4 className="mb-1">{update.title}</h4>
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge className={getSeverityColor(update.severity)}>
                              {update.severity} priority
                            </Badge>
                            <Badge variant="outline">{update.category}</Badge>
                            <Badge className={getStatusColor(update.status)}>
                              {update.status}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            Source: {update.source} • {new Date(update.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleMarkAsReviewed(update.id)}
                        >
                          Mark as Reviewed
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <p className="text-sm text-gray-700 bg-gray-50 p-3 rounded">
                        {update.description}
                      </p>
                      
                      {update.affectedDocuments > 0 && (
                        <div className="flex items-center space-x-2 text-sm text-orange-600">
                          <AlertTriangle className="h-4 w-4" />
                          <span>
                            May affect {update.affectedDocuments} document{update.affectedDocuments > 1 ? 's' : ''} in your library
                          </span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="reviewed" className="space-y-4">
          {reviewedUpdates.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Clock className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg mb-2">No Items Under Review</h3>
                <p className="text-gray-500">
                  Updates marked for review will appear here.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {reviewedUpdates.map((update) => (
                <Card key={update.id} className="border-l-4 border-l-orange-500">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-5 w-5 text-orange-600" />
                        <div>
                          <h4 className="mb-1">{update.title}</h4>
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge className={getSeverityColor(update.severity)}>
                              {update.severity} priority
                            </Badge>
                            <Badge variant="outline">{update.category}</Badge>
                            <Badge className={getStatusColor(update.status)}>
                              under review
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            Source: {update.source} • {new Date(update.date).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleMarkAsImplemented(update.id)}
                      >
                        Mark as Implemented
                      </Button>
                    </div>

                    <p className="text-sm text-gray-700">
                      {update.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="implemented" className="space-y-4">
          {implementedUpdates.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg mb-2">No Implemented Changes</h3>
                <p className="text-gray-500">
                  Updates you've implemented will be tracked here.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {implementedUpdates.map((update) => (
                <Card key={update.id} className="border-l-4 border-l-green-500 opacity-75">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                      <div>
                        <h4 className="mb-1">{update.title}</h4>
                        <div className="flex items-center space-x-2 mb-2">
                          <Badge className="bg-green-100 text-green-800">
                            Implemented
                          </Badge>
                          <Badge variant="outline">{update.category}</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Source: {update.source} • {new Date(update.date).toLocaleDateString()}
                        </p>
                        <p className="text-sm text-gray-700 mt-2">
                          {update.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="sources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Monitored Sources</CardTitle>
              <CardDescription>
                Configure which regulatory sources to monitor for compliance updates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {monitoredSources.map((source, index) => (
                  <div key={source.name} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full ${source.active ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                      <div>
                        <p className="font-medium">{source.name}</p>
                        <p className="text-sm text-gray-600">{source.category}</p>
                      </div>
                    </div>
                    <Button
                      variant={source.active ? "destructive" : "default"}
                      size="sm"
                      onClick={() => {
                        const newSources = [...monitoredSources];
                        newSources[index].active = !newSources[index].active;
                        setMonitoredSources(newSources);
                      }}
                    >
                      {source.active ? 'Disable' : 'Enable'}
                    </Button>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-start space-x-2">
                  <Settings className="h-5 w-5 text-blue-600 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-blue-900">Monitoring Configuration</h4>
                    <p className="text-sm text-blue-700 mt-1">
                      The system checks for updates from enabled sources every 24 hours. 
                      You can also trigger manual checks using the "Check for Updates" button.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}