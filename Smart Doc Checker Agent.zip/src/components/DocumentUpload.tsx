import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Upload, FileText, X, CheckCircle } from 'lucide-react';

interface DocumentUploadProps {
  onUpload: (file: File, type: string) => Promise<void>;
}

export function DocumentUpload({ onUpload }: DocumentUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [documentTypes, setDocumentTypes] = useState<{ [key: string]: string }>({});
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => 
      file.type === 'application/pdf' || 
      file.type.startsWith('image/') || 
      file.type.includes('document') ||
      file.type.includes('text')
    );
    
    setSelectedFiles(prev => [...prev, ...validFiles]);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setSelectedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setSelectedFiles(prev => prev.filter((_, i) => i !== index));
    setDocumentTypes(prev => {
      const newTypes = { ...prev };
      delete newTypes[index.toString()];
      return newTypes;
    });
  };

  const setFileType = (index: number, type: string) => {
    setDocumentTypes(prev => ({
      ...prev,
      [index.toString()]: type
    }));
  };

  const handleUploadAll = async () => {
    setUploading(true);
    
    try {
      for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        const type = documentTypes[i.toString()] || 'other';
        await onUpload(file, type);
      }
      
      // Clear files after successful upload
      setSelectedFiles([]);
      setDocumentTypes({});
    } catch (error) {
      console.error('Upload error:', error);
    } finally {
      setUploading(false);
    }
  };

  const canUpload = selectedFiles.length > 0 && 
    selectedFiles.every((_, index) => documentTypes[index.toString()]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload Documents</CardTitle>
          <CardDescription>
            Upload your documents for AI-powered analysis and conflict detection.
            Supported formats: PDF, Word documents, images, and text files.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* Drag & Drop Area */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              dragActive
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-300 hover:border-gray-400'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <div className="space-y-2">
              <p className="text-lg">Drop files here, or click to select</p>
              <p className="text-sm text-gray-500">
                Supports PDF, Word documents, images, and text files
              </p>
            </div>
            <Button
              type="button"
              variant="outline"
              className="mt-4"
              onClick={() => fileInputRef.current?.click()}
            >
              Browse Files
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".pdf,.doc,.docx,.txt,.md,.jpg,.jpeg,.png,.gif"
              onChange={handleFileSelect}
              className="hidden"
            />
          </div>

          {/* Selected Files */}
          {selectedFiles.length > 0 && (
            <div className="mt-6">
              <h3 className="mb-4">Selected Files ({selectedFiles.length})</h3>
              <div className="space-y-3">
                {selectedFiles.map((file, index) => (
                  <div
                    key={`${file.name}-${index}`}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-gray-600" />
                      <div>
                        <p className="font-medium text-sm">{file.name}</p>
                        <p className="text-xs text-gray-500">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <Select
                        value={documentTypes[index.toString()] || ''}
                        onValueChange={(value) => setFileType(index, value)}
                      >
                        <SelectTrigger className="w-40">
                          <SelectValue placeholder="Document type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="resume">Resume/CV</SelectItem>
                          <SelectItem value="medical">Medical Report</SelectItem>
                          <SelectItem value="policy">Policy Document</SelectItem>
                          <SelectItem value="contract">Contract</SelectItem>
                          <SelectItem value="note">Note/Memo</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 flex justify-end">
                <Button
                  onClick={handleUploadAll}
                  disabled={!canUpload || uploading}
                  className="min-w-32"
                >
                  {uploading ? (
                    <div className="flex items-center space-x-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                      <span>Uploading...</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <Upload className="h-4 w-4" />
                      <span>Upload All</span>
                    </div>
                  )}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upload Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle>Document Guidelines</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="mb-2">Supported Document Types</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Resumes and CVs</li>
                <li>• Medical reports and records</li>
                <li>• Policy documents</li>
                <li>• Contracts and agreements</li>
                <li>• Notes and memos</li>
                <li>• General documents</li>
              </ul>
            </div>
            
            <div>
              <h4 className="mb-2">AI Analysis Features</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Conflict detection across documents</li>
                <li>• Policy compliance checking</li>
                <li>• Ambiguity identification</li>
                <li>• Smart recommendations</li>
                <li>• Automated categorization</li>
                <li>• Content summarization</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}