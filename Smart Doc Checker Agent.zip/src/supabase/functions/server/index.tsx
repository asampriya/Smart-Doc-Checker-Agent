import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Enable CORS for all routes
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Enable logging
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Create storage bucket on startup
async function initializeStorage() {
  const bucketName = 'make-c5e20b83-documents';
  
  try {
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
    
    if (!bucketExists) {
      const { error } = await supabase.storage.createBucket(bucketName, {
        public: false,
        allowedMimeTypes: [
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          'text/plain',
          'text/markdown',
          'image/jpeg',
          'image/png',
          'image/gif'
        ],
        fileSizeLimit: 50 * 1024 * 1024 // 50MB
      });
      
      if (error) {
        console.error('Error creating bucket:', error);
      } else {
        console.log('Created documents bucket successfully');
      }
    }
  } catch (error) {
    console.error('Error initializing storage:', error);
  }
}

// Initialize storage on startup
initializeStorage();

// Initialize demo data
async function initializeDemoData() {
  try {
    const existingDocuments = await kv.get('demo:documents');
    const existingConflicts = await kv.get('demo:conflicts');
    
    if (!existingDocuments || existingDocuments.length === 0) {
      const demoDocuments = [
        {
          id: 'demo_doc_1',
          name: 'Employee_Handbook_2024.pdf',
          type: 'policy',
          uploadDate: '2024-01-10T10:00:00Z',
          status: 'analyzed',
          conflicts: 2,
          analysisDate: '2024-01-10T10:05:00Z',
          summary: 'AI analysis completed for policy document: Employee_Handbook_2024.pdf'
        },
        {
          id: 'demo_doc_2',
          name: 'Patient_Consent_Form.pdf',
          type: 'medical',
          uploadDate: '2024-01-12T14:30:00Z',
          status: 'analyzed',
          conflicts: 1,
          analysisDate: '2024-01-12T14:35:00Z',
          summary: 'AI analysis completed for medical document: Patient_Consent_Form.pdf'
        },
        {
          id: 'demo_doc_3',
          name: 'Data_Privacy_Policy.docx',
          type: 'policy',
          uploadDate: '2024-01-15T09:15:00Z',
          status: 'analyzed',
          conflicts: 0,
          analysisDate: '2024-01-15T09:20:00Z',
          summary: 'AI analysis completed for policy document: Data_Privacy_Policy.docx'
        }
      ];
      
      await kv.set('demo:documents', demoDocuments);
      console.log('Initialized demo documents');
    }
    
    if (!existingConflicts || existingConflicts.length === 0) {
      const demoConflicts = [
        {
          id: 'demo_conflict_1',
          type: 'policy',
          severity: 'high',
          description: 'Policy contradiction: Employee handbook remote work policy conflicts with established HR guidelines regarding work-from-home eligibility criteria.',
          documents: ['demo_doc_1'],
          recommendation: 'Review and reconcile remote work policies between employee handbook and HR guidelines to ensure organizational consistency.',
          status: 'unresolved',
          createdAt: '2024-01-10T10:05:00Z',
          documentName: 'Employee_Handbook_2024.pdf'
        },
        {
          id: 'demo_conflict_2',
          type: 'compliance',
          severity: 'medium',
          description: 'Regulatory compliance gap: Employee handbook disciplinary procedures may not fully address current employment law requirements for progressive discipline.',
          documents: ['demo_doc_1'],
          recommendation: 'Update disciplinary procedures to ensure full compliance with latest employment law guidelines and standards.',
          status: 'unresolved',
          createdAt: '2024-01-10T10:05:00Z',
          documentName: 'Employee_Handbook_2024.pdf'
        },
        {
          id: 'demo_conflict_3',
          type: 'compliance',
          severity: 'high',
          description: 'Potential HIPAA compliance issue: Patient consent form may not clearly address all required disclosure requirements for electronic health information sharing.',
          documents: ['demo_doc_2'],
          recommendation: 'Review patient consent forms and ensure all HIPAA disclosure requirements for electronic health information are explicitly documented.',
          status: 'unresolved',
          createdAt: '2024-01-12T14:35:00Z',
          documentName: 'Patient_Consent_Form.pdf'
        }
      ];
      
      await kv.set('demo:conflicts', demoConflicts);
      console.log('Initialized demo conflicts');
    }
  } catch (error) {
    console.error('Error initializing demo data:', error);
  }
}

// Initialize demo data on startup
initializeDemoData();

// Middleware to verify user authentication
async function verifyAuth(c: any, next: () => Promise<void>) {
  const authHeader = c.req.header('Authorization');
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ error: 'Missing or invalid authorization header' }, 401);
  }

  const accessToken = authHeader.split(' ')[1];
  
  try {
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (error || !user?.id) {
      console.error('Auth verification error:', error);
      return c.json({ error: 'Unauthorized' }, 401);
    }
    
    c.set('userId', user.id);
    c.set('userEmail', user.email);
    await next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    return c.json({ error: 'Authorization failed' }, 401);
  }
}

// Sign up route
app.post('/make-server-c5e20b83/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: 'Missing required fields' }, 400);
    }

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.error('Sign up error:', error);
      return c.json({ error: error.message }, 400);
    }

    // Initialize user data
    await kv.set(`user:${data.user.id}:documents`, []);
    await kv.set(`user:${data.user.id}:conflicts`, []);

    return c.json({ user: data.user });
  } catch (error) {
    console.error('Signup route error:', error);
    return c.json({ error: 'Internal server error during signup' }, 500);
  }
});

// Get user documents and conflicts
app.get('/make-server-c5e20b83/documents', async (c) => {
  try {
    // For demo purposes, we'll use the anon key to get data
    // In a real app, this would be protected with auth
    const documents = await kv.get('demo:documents') || [];
    const conflicts = await kv.get('demo:conflicts') || [];
    
    return c.json({ documents, conflicts });
  } catch (error) {
    console.error('Error loading documents:', error);
    return c.json({ error: 'Failed to load documents' }, 500);
  }
});

// Document upload route
app.post('/make-server-c5e20b83/upload', verifyAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    const type = formData.get('type') as string;

    if (!file || !type) {
      return c.json({ error: 'Missing file or type' }, 400);
    }

    // Generate unique file path
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Date.now()}-${Math.random().toString(36).substr(2, 9)}.${fileExt}`;
    
    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase.storage
      .from('make-c5e20b83-documents')
      .upload(fileName, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      return c.json({ error: 'Failed to upload file' }, 500);
    }

    // Create signed URL for download
    const { data: urlData, error: urlError } = await supabase.storage
      .from('make-c5e20b83-documents')
      .createSignedUrl(fileName, 60 * 60 * 24 * 7); // 7 days

    if (urlError) {
      console.error('URL generation error:', urlError);
    }

    // Create document record
    const document = {
      id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: file.name,
      type,
      uploadDate: new Date().toISOString(),
      status: 'processing',
      url: urlData?.signedUrl,
      userId
    };

    // Store document metadata
    const userDocuments = await kv.get(`user:${userId}:documents`) || [];
    userDocuments.push(document);
    await kv.set(`user:${userId}:documents`, userDocuments);

    // For demo, also store in demo namespace
    const demoDocuments = await kv.get('demo:documents') || [];
    demoDocuments.push(document);
    await kv.set('demo:documents', demoDocuments);

    // Trigger AI analysis (simulate)
    setTimeout(async () => {
      await analyzeDocumentContent(document, userId);
    }, 2000);

    return c.json({ document });
  } catch (error) {
    console.error('Upload route error:', error);
    return c.json({ error: 'Internal server error during upload' }, 500);
  }
});

// OpenAI integration for document analysis
async function analyzeDocumentWithOpenAI(document: any, fileContent: string, userId: string) {
  try {
    const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiApiKey) {
      console.log('OpenAI API key not found, falling back to simulated analysis');
      return await analyzeDocument(document, userId);
    }

    console.log(`Starting OpenAI analysis for document: ${document.name}`);

    const prompt = `As an AI document analysis assistant, analyze the following document for potential conflicts, compliance issues, and ambiguities. The document type is: ${document.type}.

Document content:
${fileContent.substring(0, 4000)} ${fileContent.length > 4000 ? '...[truncated]' : ''}

Please provide a detailed analysis in the following JSON format:
{
  "summary": "Brief summary of the document analysis",
  "confidence": 0.85,
  "conflicts": [
    {
      "type": "policy|compliance|ambiguity",
      "severity": "low|medium|high",
      "description": "Detailed description of the issue",
      "recommendation": "Specific recommendation to resolve the issue",
      "location": "Section or area where issue was found"
    }
  ],
  "keyFindings": [
    "List of key findings from the analysis"
  ]
}

Focus on:
- Policy contradictions or inconsistencies
- Regulatory compliance gaps
- Ambiguous language that could cause confusion
- Missing required information
- Potential legal or operational risks

Provide specific, actionable recommendations for each issue identified.`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${openaiApiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          {
            role: 'system',
            content: 'You are an expert document analyst specializing in identifying conflicts, compliance issues, and ambiguities in various types of documents. Provide thorough, accurate analysis with actionable recommendations.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 2000,
        temperature: 0.3
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('OpenAI API error:', error);
      throw new Error(`OpenAI API error: ${response.status}`);
    }

    const openaiResult = await response.json();
    const analysisText = openaiResult.choices[0]?.message?.content;

    if (!analysisText) {
      throw new Error('No analysis content received from OpenAI');
    }

    // Parse the JSON response from OpenAI
    let analysisData;
    try {
      // Extract JSON from the response (in case there's extra text)
      const jsonMatch = analysisText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        analysisData = JSON.parse(jsonMatch[0]);
      } else {
        throw new Error('No JSON found in OpenAI response');
      }
    } catch (parseError) {
      console.error('Error parsing OpenAI response:', parseError);
      console.log('Raw OpenAI response:', analysisText);
      
      // Fallback to simulated analysis if JSON parsing fails
      return await analyzeDocument(document, userId);
    }

    // Store conflicts from OpenAI analysis
    const conflicts = analysisData.conflicts || [];
    const storedConflicts = [];

    for (let i = 0; i < conflicts.length; i++) {
      const conflict = conflicts[i];
      const newConflict = {
        id: `openai_conflict_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 9)}`,
        type: conflict.type || 'ambiguity',
        severity: conflict.severity || 'medium',
        description: conflict.description || 'Issue detected by AI analysis',
        documents: [document.id],
        recommendation: conflict.recommendation || 'Review and address the identified issue',
        status: 'unresolved',
        createdAt: new Date().toISOString(),
        documentName: document.name,
        location: conflict.location || 'Document content',
        source: 'OpenAI Analysis'
      };

      // Store conflict for user
      const userConflicts = await kv.get(`user:${userId}:conflicts`) || [];
      userConflicts.push(newConflict);
      await kv.set(`user:${userId}:conflicts`, userConflicts);
      
      // Store for demo
      const demoConflicts = await kv.get('demo:conflicts') || [];
      demoConflicts.push(newConflict);
      await kv.set('demo:conflicts', demoConflicts);
      
      storedConflicts.push(newConflict);
    }

    // Update document status with OpenAI analysis results
    const analysisResults = {
      summary: analysisData.summary || `OpenAI analysis completed for ${document.type} document: ${document.name}`,
      confidence: analysisData.confidence || 0.85,
      conflictCount: conflicts.length,
      keyFindings: analysisData.keyFindings || [],
      source: 'OpenAI GPT-4'
    };

    const userDocuments = await kv.get(`user:${userId}:documents`) || [];
    const updatedDocuments = userDocuments.map((doc: any) => 
      doc.id === document.id 
        ? { 
            ...doc, 
            status: 'analyzed', 
            conflicts: analysisResults.conflictCount,
            analysisDate: new Date().toISOString(),
            summary: analysisResults.summary,
            aiSummary: analysisResults.summary,
            confidence: analysisResults.confidence,
            keyFindings: analysisResults.keyFindings
          }
        : doc
    );
    await kv.set(`user:${userId}:documents`, updatedDocuments);

    // Update demo documents too
    const demoDocuments = await kv.get('demo:documents') || [];
    const updatedDemoDocuments = demoDocuments.map((doc: any) => 
      doc.id === document.id 
        ? { 
            ...doc, 
            status: 'analyzed', 
            conflicts: analysisResults.conflictCount,
            analysisDate: new Date().toISOString(),
            summary: analysisResults.summary,
            aiSummary: analysisResults.summary,
            confidence: analysisResults.confidence,
            keyFindings: analysisResults.keyFindings
          }
        : doc
    );
    await kv.set('demo:documents', updatedDemoDocuments);

    console.log(`OpenAI analysis completed for document: ${document.name}. Found ${analysisResults.conflictCount} conflicts with ${(analysisResults.confidence * 100).toFixed(1)}% confidence.`);
    
    return analysisResults;

  } catch (error) {
    console.error('Error during OpenAI document analysis:', error);
    
    // Fallback to simulated analysis
    console.log('Falling back to simulated analysis');
    return await analyzeDocument(document, userId);
  }
}

// Enhanced document analysis function
async function analyzeDocumentContent(document: any, userId: string) {
  try {
    console.log(`Starting enhanced analysis for document: ${document.name}`);
    
    // In a real implementation, you would extract text from the uploaded file
    // For demo purposes, we'll use a placeholder content or try to read if it's a text file
    let fileContent = '';
    
    try {
      // Try to get the file content from storage for text-based analysis
      if (document.url) {
        // This would normally extract text from PDF, DOCX, etc.
        // For demo, we'll simulate some content based on document type
        switch (document.type) {
          case 'policy':
            fileContent = `
              Company Policy Document
              
              Remote Work Policy:
              Employees may work remotely up to 3 days per week with manager approval.
              All remote work must be approved in advance and documented.
              
              Disciplinary Procedures:
              Progressive discipline includes verbal warning, written warning, suspension, and termination.
              All disciplinary actions must be documented and reviewed by HR.
              
              Data Security:
              Employees must use company VPN when accessing company systems remotely.
              Personal devices used for work must have approved security software installed.
            `;
            break;
            
          case 'medical':
            fileContent = `
              Patient Consent Form
              
              I understand that my medical information may be shared with:
              - Healthcare providers involved in my care
              - Insurance companies for billing purposes
              - Healthcare facilities for coordination of care
              
              Electronic Health Records:
              I consent to the electronic storage and transmission of my health information.
              I understand that electronic systems may be subject to security risks.
              
              Patient Rights:
              I have the right to access my medical records.
              I have the right to request corrections to my medical information.
            `;
            break;
            
          case 'contract':
            fileContent = `
              Employment Contract
              
              Position: Software Developer
              Start Date: January 1, 2024
              Salary: $75,000 per year
              
              Termination Clause:
              Either party may terminate this agreement with 30 days written notice.
              Termination for cause may be immediate without notice.
              
              Non-Disclosure Agreement:
              Employee agrees not to disclose confidential company information.
              This obligation continues for 2 years after termination of employment.
            `;
            break;
            
          default:
            fileContent = `Sample document content for analysis. This document contains various policies and procedures that need to be reviewed for conflicts and compliance issues.`;
        }
      }
    } catch (contentError) {
      console.error('Error extracting file content:', contentError);
      fileContent = `Document content extraction failed. Analyzing document metadata: ${document.name}, type: ${document.type}`;
    }

    // Use OpenAI for analysis if available, otherwise fall back to simulation
    return await analyzeDocumentWithOpenAI(document, fileContent, userId);
    
  } catch (error) {
    console.error('Error during enhanced document analysis:', error);
    
    // Final fallback to simulated analysis
    return await analyzeDocument(document, userId);
  }
}

// AI analysis function (simulated)
async function analyzeDocument(document: any, userId: string) {
  try {
    console.log(`Starting AI analysis for document: ${document.name}`);
    
    // Simulate AI analysis delay
    await new Promise(resolve => setTimeout(resolve, 3000));

    // More sophisticated conflict detection simulation
    const conflictTypes = ['policy', 'compliance', 'ambiguity'];
    const severities = ['low', 'medium', 'high'];
    
    const analysisResults = {
      hasConflicts: Math.random() > 0.6, // 40% chance of conflicts
      conflictCount: 0,
      summary: `AI analysis completed for ${document.type} document: ${document.name}`,
      detectedIssues: []
    };

    // Generate realistic conflicts based on document type
    if (analysisResults.hasConflicts) {
      const numConflicts = Math.floor(Math.random() * 3) + 1; // 1-3 conflicts
      analysisResults.conflictCount = numConflicts;
      
      for (let i = 0; i < numConflicts; i++) {
        const conflictType = conflictTypes[Math.floor(Math.random() * conflictTypes.length)];
        const severity = severities[Math.floor(Math.random() * severities.length)];
        
        let description = '';
        let recommendation = '';
        
        // Generate context-aware descriptions based on document type
        switch (document.type) {
          case 'medical':
            if (conflictType === 'compliance') {
              description = 'Potential HIPAA compliance issue: Patient information disclosure requirements may not be clearly addressed.';
              recommendation = 'Review patient consent forms and ensure all HIPAA disclosure requirements are explicitly documented.';
            } else if (conflictType === 'policy') {
              description = 'Medical protocol inconsistency: Treatment procedures may conflict with established medical guidelines.';
              recommendation = 'Align treatment protocols with current medical standards and update documentation accordingly.';
            } else {
              description = 'Ambiguous medical terminology: Some medical terms may be unclear or inconsistently used.';
              recommendation = 'Standardize medical terminology and provide clear definitions for all technical terms.';
            }
            break;
            
          case 'policy':
            if (conflictType === 'compliance') {
              description = 'Regulatory compliance gap: Policy may not fully address current regulatory requirements.';
              recommendation = 'Update policy to ensure full compliance with latest regulatory guidelines and standards.';
            } else if (conflictType === 'policy') {
              description = 'Policy contradiction: This policy may conflict with existing organizational policies.';
              recommendation = 'Review and reconcile conflicting policies to ensure organizational consistency.';
            } else {
              description = 'Policy ambiguity: Some policy statements are unclear and may lead to misinterpretation.';
              recommendation = 'Clarify ambiguous policy language and provide specific implementation guidelines.';
            }
            break;
            
          case 'resume':
            if (conflictType === 'compliance') {
              description = 'Employment law concern: Resume format may not comply with equal opportunity requirements.';
              recommendation = 'Ensure resume format complies with employment discrimination laws and best practices.';
            } else {
              description = 'Information consistency issue: Some employment details may be inconsistent or unclear.';
              recommendation = 'Verify and standardize employment information for accuracy and clarity.';
            }
            break;
            
          default:
            description = `Potential ${conflictType} issue detected in document content.`;
            recommendation = `Review document for ${conflictType} concerns and make necessary corrections.`;
        }

        const newConflict = {
          id: `conflict_${Date.now()}_${i}_${Math.random().toString(36).substr(2, 9)}`,
          type: conflictType,
          severity,
          description,
          documents: [document.id],
          recommendation,
          status: 'unresolved',
          createdAt: new Date().toISOString(),
          documentName: document.name
        };

        // Store conflict for user
        const conflicts = await kv.get(`user:${userId}:conflicts`) || [];
        conflicts.push(newConflict);
        await kv.set(`user:${userId}:conflicts`, conflicts);
        
        // Store for demo
        const demoConflicts = await kv.get('demo:conflicts') || [];
        demoConflicts.push(newConflict);
        await kv.set('demo:conflicts', demoConflicts);
        
        analysisResults.detectedIssues.push(newConflict);
      }
    }

    // Update document status with analysis results
    const userDocuments = await kv.get(`user:${userId}:documents`) || [];
    const updatedDocuments = userDocuments.map((doc: any) => 
      doc.id === document.id 
        ? { 
            ...doc, 
            status: 'analyzed', 
            conflicts: analysisResults.conflictCount,
            analysisDate: new Date().toISOString(),
            summary: analysisResults.summary
          }
        : doc
    );
    await kv.set(`user:${userId}:documents`, updatedDocuments);

    // Update demo documents too
    const demoDocuments = await kv.get('demo:documents') || [];
    const updatedDemoDocuments = demoDocuments.map((doc: any) => 
      doc.id === document.id 
        ? { 
            ...doc, 
            status: 'analyzed', 
            conflicts: analysisResults.conflictCount,
            analysisDate: new Date().toISOString(),
            summary: analysisResults.summary
          }
        : doc
    );
    await kv.set('demo:documents', updatedDemoDocuments);

    console.log(`Analysis completed for document: ${document.name}. Found ${analysisResults.conflictCount} conflicts.`);
    
    // Log analysis results for debugging
    console.log('Analysis results:', JSON.stringify(analysisResults, null, 2));

  } catch (error) {
    console.error('Error during document analysis:', error);
    
    // Update document status to error
    try {
      const userDocuments = await kv.get(`user:${userId}:documents`) || [];
      const updatedDocuments = userDocuments.map((doc: any) => 
        doc.id === document.id 
          ? { ...doc, status: 'error', errorMessage: 'Analysis failed' }
          : doc
      );
      await kv.set(`user:${userId}:documents`, updatedDocuments);
      
      // Update demo documents too
      const demoDocuments = await kv.get('demo:documents') || [];
      const updatedDemoDocuments = demoDocuments.map((doc: any) => 
        doc.id === document.id 
          ? { ...doc, status: 'error', errorMessage: 'Analysis failed' }
          : doc
      );
      await kv.set('demo:documents', updatedDemoDocuments);
    } catch (updateError) {
      console.error('Error updating document status to error:', updateError);
    }
  }
}

// Resolve conflict route
app.post('/make-server-c5e20b83/resolve-conflict/:conflictId', verifyAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const conflictId = c.req.param('conflictId');
    
    const conflicts = await kv.get(`user:${userId}:conflicts`) || [];
    const updatedConflicts = conflicts.map((conflict: any) => 
      conflict.id === conflictId 
        ? { ...conflict, status: 'resolved' }
        : conflict
    );
    
    await kv.set(`user:${userId}:conflicts`, updatedConflicts);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error resolving conflict:', error);
    return c.json({ error: 'Failed to resolve conflict' }, 500);
  }
});

// Compliance monitoring route
app.get('/make-server-c5e20b83/compliance-updates', async (c) => {
  try {
    // This would normally fetch from external compliance APIs
    // For demo, return mock data
    const updates = [
      {
        id: 'update_1',
        source: 'Federal Register',
        title: 'Updated GDPR Data Processing Guidelines',
        description: 'New requirements for data processing consent documentation.',
        severity: 'high',
        date: new Date().toISOString(),
        category: 'Data Privacy',
        status: 'new'
      }
    ];
    
    return c.json({ updates });
  } catch (error) {
    console.error('Error fetching compliance updates:', error);
    return c.json({ error: 'Failed to fetch compliance updates' }, 500);
  }
});

// Health check route
app.get('/make-server-c5e20b83/health', (c) => {
  return c.json({ status: 'healthy', timestamp: new Date().toISOString() });
});

// Error handler
app.onError((err, c) => {
  console.error('Server error:', err);
  return c.json({ error: 'Internal server error' }, 500);
});

// 404 handler
app.notFound((c) => {
  return c.json({ error: 'Not found' }, 404);
});

Deno.serve(app.fetch);